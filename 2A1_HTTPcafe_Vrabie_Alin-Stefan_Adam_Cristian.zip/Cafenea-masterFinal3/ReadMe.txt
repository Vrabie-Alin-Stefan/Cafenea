	Prima pagina a site-ului este HomePage care va genera un token stocat in cookie folosit pentru 
a tine minte utilizatorul conectat de unde se poate intra pe pagina de contacte sau 
se poate accesa pagina localului ori exista posibilitatea
vizualizarii unei scurte prezentari a cafenelei.
	Pagina local prezinta in timp real gradul de ocupare a cafenelei, atunci cand un nou client
va intra va avea posibilitatea ocuparii unei mese noi, ocuparea unei mese va redirectiona utilizatorul catre o 
pagina de selectare a tipului de bautura dorit.
	Pagina de prezentare a bauturii va da posibilitatea intrarii in meniul propriu zis al cafenelei
	Meniul propriu zis al cafenelei contine o lista cu toate bauturile puse la dispozitie
	Pagina de contact ofera informatii pentru contactul personalului cafenelei
	Dupa comandarea unei bauturi, clientul are posibilitatea de a cere nota de plata si astfel va 
elibera masa sau poate comanda si alte produse
